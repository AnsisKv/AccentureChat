//
//  ViewController.swift
//  AccentureChat
//
//  Created by kvelde.niklavs.ansis on 17/05/2023.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

