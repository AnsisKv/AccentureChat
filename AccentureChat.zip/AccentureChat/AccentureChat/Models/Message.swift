//
//  Message.swift
//  AccentureChat
//
//  Created by kvelde.niklavs.ansis on 22/05/2023.
//

import Foundation

struct Message {
    let sender: String
    let body: String
}
